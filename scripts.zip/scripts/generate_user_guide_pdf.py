from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from textwrap import wrap

PAGE_WIDTH = 595
PAGE_HEIGHT = 842
LEFT_MARGIN = 54
TOP_MARGIN = 790


@dataclass(frozen=True)
class StyledLine:
    text: str
    font: str = "F1"
    size: int = 11
    leading: int = 15


def build_pages() -> list[list[StyledLine]]:
    page_one: list[StyledLine] = [
        StyledLine("EuroMacro Copilot", font="F2", size=24, leading=30),
        StyledLine("Guide d'utilisation de l'application web", font="F1", size=12, leading=20),
        StyledLine("", leading=12),
    ]
    page_one.extend(
        section(
            "1. Lancer l'application",
            [
                "Activez l'environnement virtuel du projet puis lancez l'interface avec la commande : streamlit run app.py.",
                "Au chargement, la page d'accueil affiche un bandeau de synthèse avec le volume du corpus indexé, le score d'incertitude macro et l'état du moteur de réponse.",
                "La barre latérale rappelle où déposer de nouvelles sources et propose des liens directs vers les jeux de données officiels recommandés.",
            ],
        )
    )
    page_one.extend(
        section(
            "2. Lire le tableau de bord",
            [
                "Les quatre cartes principales donnent une lecture immédiate de l'inflation IPCH, de l'inflation sous-jacente, du coût du financement et du taux de chômage.",
                "Chaque carte affiche la dernière valeur disponible, la variation par rapport à l'observation précédente et la date de mise à jour. Cela permet d'identifier rapidement si la dynamique est en hausse, en baisse ou stable.",
                "Dans la colonne de droite, le bloc 'Narratifs détectés' met en avant les thèmes les plus présents dans le corpus documentaire : choc énergie, faiblesse de la demande, resserrement financier ou résilience du marché du travail.",
            ],
        )
    )
    page_one.extend(
        section(
            "3. Explorer les indicateurs",
            [
                "Utilisez la liste déroulante centrale pour choisir la série à examiner. Deux onglets permettent ensuite de basculer entre la courbe d'évolution et le tableau détaillé des observations.",
                "La vue 'Courbe' aide à repérer la trajectoire générale de l'indicateur. La vue 'Tableau' est utile pour vérifier les dates et comparer précisément les derniers points.",
                "Le bloc 'Questions utiles' fournit des formulations prêtes à l'emploi si vous souhaitez démarrer rapidement un échange dans le chat analytique.",
            ],
        )
    )
    page_one.extend(
        section(
            "Repère pratique",
            [
                "Les séries incluses dans le projet sont des données de démonstration. Elles servent à illustrer l'usage de l'application et non à remplacer une base officielle en temps réel.",
            ],
        )
    )
    page_one.extend(page_footer(1))

    page_two: list[StyledLine] = [
        StyledLine("Utiliser le copilote au quotidien", font="F2", size=20, leading=28),
        StyledLine("", leading=12),
    ]
    page_two.extend(
        section(
            "4. Poser une question dans le chat",
            [
                "En bas de l'écran, saisissez une question métier ou macroéconomique. Exemple : 'Que signifie le reflux de l'inflation pour ma politique tarifaire ?'",
                "Le copilote répond en français avec une structure simple : diagnostic, implications PME, variables à surveiller et sources utilisées.",
                "Lorsque le modèle distant n'est pas configuré, l'application bascule automatiquement sur une réponse heuristique locale. Le résultat reste exploitable pour un premier cadrage analytique.",
            ],
        )
    )
    page_two.extend(
        section(
            "5. Consulter les sources mobilisées",
            [
                "Chaque réponse assistant peut être dépliée pour afficher les extraits de documents ayant servi à la réponse. Le score de pertinence aide à comprendre pourquoi une source a été retenue.",
                "Cette étape est importante pour vérifier l'argumentation et distinguer ce qui vient des documents, des séries de démonstration et de l'interprétation produite par le système.",
            ],
        )
    )
    page_two.extend(
        section(
            "6. Ajouter ou remplacer des documents",
            [
                "Placez vos notes Markdown, fichiers texte, pages HTML ou exports préparés dans data/documents/. Les fichiers externes récupérés depuis des sites officiels peuvent être déposés dans data/external/.",
                "Le chargeur gère désormais les encodages les plus courants, notamment UTF-8, UTF-8 avec BOM, CP1252 et Latin-1. Les accents français et caractères spéciaux sont donc mieux préservés.",
                "Après ajout ou modification du corpus, relancez l'application pour reconstruire l'index local et prendre en compte les nouveaux contenus.",
            ],
        )
    )
    page_two.extend(
        section(
            "Bonnes pratiques",
            [
                "Formulez des questions ciblées : financement, prix, investissement, recrutement ou lecture d'un narratif BCE. Plus la question est précise, plus la réponse sera utile.",
                "Croisez toujours la réponse du copilote avec votre contexte métier, vos données internes et, si nécessaire, les sources officielles. L'application est un outil d'aide à la décision, pas un substitut à l'analyse finale.",
            ],
        )
    )
    page_two.extend(page_footer(2))

    return [page_one, page_two]


def section(title: str, paragraphs: list[str]) -> list[StyledLine]:
    lines = [StyledLine(title, font="F2", size=15, leading=22)]
    for paragraph in paragraphs:
        lines.extend(wrap_paragraph(paragraph))
        lines.append(StyledLine("", leading=11))
    return lines


def wrap_paragraph(text: str, width: int = 92) -> list[StyledLine]:
    wrapped = wrap(text, width=width, break_long_words=False, break_on_hyphens=False) or [""]
    return [StyledLine(line) for line in wrapped]


def page_footer(page_number: int) -> list[StyledLine]:
    return [
        StyledLine("", leading=12),
        StyledLine(f"Page {page_number}/2", font="F1", size=10, leading=12),
    ]


def build_content_stream(lines: list[StyledLine]) -> bytes:
    commands = ["BT", f"1 0 0 1 {LEFT_MARGIN} {TOP_MARGIN} Tm"]
    current_font: tuple[str, int] | None = None
    current_leading: int | None = None

    for index, line in enumerate(lines):
        font_key = (line.font, line.size)
        if font_key != current_font:
            commands.append(f"/{line.font} {line.size} Tf")
            current_font = font_key
        if line.leading != current_leading:
            commands.append(f"{line.leading} TL")
            current_leading = line.leading

        if index > 0:
            commands.append("T*")
        commands.append(f"({escape_pdf_text(line.text)}) Tj")

    commands.append("ET")
    return "\n".join(commands).encode("cp1252")


def escape_pdf_text(value: str) -> str:
    return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def stream_object(data: bytes) -> bytes:
    header = f"<< /Length {len(data)} >>\nstream\n".encode("ascii")
    return header + data + b"\nendstream"


def write_pdf(output_path: Path, pages: list[list[StyledLine]]) -> None:
    streams = [build_content_stream(page) for page in pages]
    page_object_numbers = [5 + index * 2 for index in range(len(streams))]
    content_object_numbers = [number + 1 for number in page_object_numbers]

    objects: list[str | bytes | None] = [None] * (4 + len(streams) * 2)
    objects[0] = "<< /Type /Catalog /Pages 2 0 R >>"
    kids = " ".join(f"{number} 0 R" for number in page_object_numbers)
    objects[1] = f"<< /Type /Pages /Count {len(streams)} /Kids [{kids}] >>"
    objects[2] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
    objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"

    for index, stream in enumerate(streams):
        page_number = page_object_numbers[index]
        content_number = content_object_numbers[index]
        objects[page_number - 1] = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PAGE_WIDTH} {PAGE_HEIGHT}] "
            f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {content_number} 0 R >>"
        )
        objects[content_number - 1] = stream_object(stream)

    buffer = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for object_number, obj in enumerate(objects, start=1):
        if obj is None:
            raise ValueError(f"Objet PDF manquant: {object_number}")
        offsets.append(len(buffer))
        buffer.extend(f"{object_number} 0 obj\n".encode("ascii"))
        if isinstance(obj, bytes):
            buffer.extend(obj)
        else:
            buffer.extend(obj.encode("ascii"))
        buffer.extend(b"\nendobj\n")

    xref_position = len(buffer)
    buffer.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    buffer.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        buffer.extend(f"{offset:010} 00000 n \n".encode("ascii"))
    buffer.extend(
        (
            f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_position}\n%%EOF"
        ).encode("ascii")
    )

    output_path.write_bytes(buffer)


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    output_path = project_root / "Guide_utilisation_EuroMacro_Copilot.pdf"
    write_pdf(output_path, build_pages())
    print(f"Guide généré : {output_path}")


if __name__ == "__main__":
    main()
