from __future__ import annotations

import argparse
from pathlib import Path
from urllib import request

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "data" / "external"

PRESET_DOWNLOADS = {
    "ecb_speeches": (
        "https://www.ecb.europa.eu/press/key/shared/data/all_ECB_speeches.csv",
        "all_ECB_speeches.csv",
    ),
    "ecb_accounts_index": (
        "https://www.ecb.europa.eu/press/accounts/html/index.en.html",
        "ecb_accounts_index.html",
    ),
    "ecb_bank_lending_survey": (
        "https://www.ecb.europa.eu/stats/ecb_surveys/bank_lending_survey/html/index.en.html",
        "ecb_bank_lending_survey.html",
    ),
    "ecb_data_portal_overview": (
        "https://data.ecb.europa.eu/help/api/overview",
        "ecb_data_portal_overview.html",
    ),
    "eurostat_api_intro": (
        "https://ec.europa.eu/eurostat/web/user-guides/data-browser/api-data-access/api-introduction",
        "eurostat_api_introduction.html",
    ),
    "ec_business_surveys": (
        "https://economy-finance.ec.europa.eu/economic-forecast-and-surveys/business-and-consumer-surveys_en",
        "ec_business_consumer_surveys.html",
    ),
}


def download(url: str, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with request.urlopen(url, timeout=60) as response:
        destination.write_bytes(response.read())
    return destination


def main() -> None:
    parser = argparse.ArgumentParser(description="Download official ECB sources into data/external.")
    parser.add_argument(
        "--preset",
        action="append",
        choices=sorted(PRESET_DOWNLOADS.keys()),
        help="Named official source to download.",
    )
    parser.add_argument("--url", action="append", help="Custom URL to download.")
    parser.add_argument(
        "--output-dir",
        default=str(DEFAULT_OUTPUT_DIR),
        help="Target directory for downloaded files.",
    )
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    downloads: list[tuple[str, Path]] = []
    for preset in args.preset or []:
        url, filename = PRESET_DOWNLOADS[preset]
        downloads.append((url, output_dir / filename))

    for raw_url in args.url or []:
        filename = raw_url.rstrip("/").split("/")[-1] or "downloaded_file"
        downloads.append((raw_url, output_dir / filename))

    if not downloads:
        parser.error("No download selected. Use --preset or --url.")

    for url, destination in downloads:
        saved_to = download(url, destination)
        print(f"Downloaded {url} -> {saved_to}")


if __name__ == "__main__":
    main()
