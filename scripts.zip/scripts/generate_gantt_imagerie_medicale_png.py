from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from matplotlib.patches import Patch


MONTH_LABELS = {
    1: "janv.",
    2: "fevr.",
    3: "mars",
    4: "avr.",
    5: "mai",
    6: "juin",
    7: "juil.",
    8: "aout",
    9: "sept.",
    10: "oct.",
    11: "nov.",
    12: "dec.",
}

PROJECT_START = date(2026, 1, 14)
MILESTONE_DATE = date(2026, 3, 22)


@dataclass(frozen=True)
class Task:
    name: str
    start: date
    end: date
    effort_days: int
    deliverable: str
    phase: str
    color: str


TASKS = [
    Task(
        name="Pilotage du projet et journal de bord",
        start=PROJECT_START,
        end=MILESTONE_DATE,
        effort_days=12,
        deliverable="Suivi, arbitrages, tracabilite",
        phase="Pilotage",
        color="#64748B",
    ),
    Task(
        name="Cadrage scientifique et objectifs",
        start=date(2026, 1, 14),
        end=date(2026, 1, 18),
        effort_days=3,
        deliverable="Question de recherche et indicateurs",
        phase="Pilotage",
        color="#0F766E",
    ),
    Task(
        name="Preparation des donnees TIF et metadonnees",
        start=date(2026, 1, 16),
        end=date(2026, 1, 23),
        effort_days=4,
        deliverable="Sequence exploitable",
        phase="Donnees",
        color="#2563EB",
    ),
    Task(
        name="Pretraitement FIJI et homogeneisation",
        start=date(2026, 1, 22),
        end=date(2026, 1, 31),
        effort_days=5,
        deliverable="Images nettoyees et normalisees",
        phase="Donnees",
        color="#2563EB",
    ),
    Task(
        name="Annotation d'exemples sous ILASTIK",
        start=date(2026, 1, 28),
        end=date(2026, 2, 5),
        effort_days=6,
        deliverable="Jeu d'annotation",
        phase="Segmentation",
        color="#7C3AED",
    ),
    Task(
        name="Entrainement du modele IA et reglages",
        start=date(2026, 2, 3),
        end=date(2026, 2, 15),
        effort_days=7,
        deliverable="Modele de segmentation stabilise",
        phase="Segmentation",
        color="#7C3AED",
    ),
    Task(
        name="Controle qualite et comparaison des methodes",
        start=date(2026, 2, 12),
        end=date(2026, 2, 19),
        effort_days=5,
        deliverable="Validation classique vs IA",
        phase="Segmentation",
        color="#9333EA",
    ),
    Task(
        name="Tracking cellulaire et reglage des liens",
        start=date(2026, 2, 18),
        end=date(2026, 2, 27),
        effort_days=5,
        deliverable="Trajectoires coherentes",
        phase="Tracking",
        color="#DC2626",
    ),
    Task(
        name="Analyse quantitative des trajectoires",
        start=date(2026, 2, 26),
        end=date(2026, 3, 5),
        effort_days=4,
        deliverable="Mesures de mobilite",
        phase="Analyse",
        color="#EA580C",
    ),
    Task(
        name="Visualisations et interpretation des resultats",
        start=date(2026, 3, 3),
        end=date(2026, 3, 10),
        effort_days=4,
        deliverable="Figures et lecture critique",
        phase="Analyse",
        color="#F59E0B",
    ),
    Task(
        name="Redaction du rapport et des figures finales",
        start=date(2026, 3, 5),
        end=date(2026, 3, 18),
        effort_days=7,
        deliverable="Rapport structure",
        phase="Valorisation",
        color="#059669",
    ),
    Task(
        name="Relectures, corrections et preparation orale",
        start=date(2026, 3, 16),
        end=date(2026, 3, 21),
        effort_days=3,
        deliverable="Version finale et soutenance",
        phase="Valorisation",
        color="#10B981",
    ),
]

PHASE_ORDER = ["Pilotage", "Donnees", "Segmentation", "Tracking", "Analyse", "Valorisation"]
PHASE_COLORS = {
    "Pilotage": "#0F766E",
    "Donnees": "#2563EB",
    "Segmentation": "#7C3AED",
    "Tracking": "#DC2626",
    "Analyse": "#EA580C",
    "Valorisation": "#059669",
}


def parse_date(value: str) -> date:
    return datetime.strptime(value, "%Y-%m-%d").date()


def format_date_fr(value: date) -> str:
    return f"{value.day:02d} {MONTH_LABELS[value.month]} {value.year}"


def build_tick_dates(start: date, end: date) -> list[date]:
    ticks: list[date] = []
    current = start
    while current <= end:
        ticks.append(current)
        current += timedelta(days=7)
    if ticks[-1] != end:
        ticks.append(end)
    return ticks


def build_tasks(project_start: date, milestone_date: date) -> list[Task]:
    shift = project_start - PROJECT_START
    adjusted_tasks: list[Task] = []
    for task in TASKS:
        start = task.start + shift
        end = task.end + shift
        if end > milestone_date:
            end = milestone_date
        adjusted_tasks.append(
            Task(
                name=task.name,
                start=start,
                end=end,
                effort_days=task.effort_days,
                deliverable=task.deliverable,
                phase=task.phase,
                color=task.color,
            )
        )
    return adjusted_tasks


def build_chart(output_path: Path, project_start: date, milestone_date: date) -> None:
    tasks = build_tasks(project_start, milestone_date)
    tick_dates = build_tick_dates(project_start, milestone_date)
    total_effort = sum(task.effort_days for task in tasks)
    task_count = len(tasks)

    start_num = mdates.date2num(project_start)
    milestone_num = mdates.date2num(milestone_date)
    right_col_charge = milestone_num + 2.2
    right_col_deliverable = milestone_num + 8.3

    fig, ax = plt.subplots(figsize=(20, 10))
    fig.patch.set_facecolor("#F8FAFC")
    ax.set_facecolor("#FFFFFF")

    y_positions = list(range(task_count))[::-1]

    for idx, tick in enumerate(tick_dates[:-1]):
        next_tick = tick_dates[idx + 1]
        ax.axvspan(
            mdates.date2num(tick),
            mdates.date2num(next_tick),
            color="#F1F5F9" if idx % 2 == 0 else "#FFFFFF",
            zorder=0,
        )

    for y, task in zip(y_positions, tasks):
        left = mdates.date2num(task.start)
        width = max((task.end - task.start).days, 1)
        ax.barh(
            y=y,
            width=width,
            left=left,
            height=0.62,
            color=task.color,
            edgecolor="#0F172A",
            linewidth=0.6,
            zorder=3,
        )
        duration_label = max((task.end - task.start).days, 1)
        ax.text(
            left + 0.4,
            y,
            f"{duration_label} j",
            va="center",
            ha="left",
            fontsize=9,
            color="white",
            fontweight="bold",
            zorder=4,
        )
        ax.text(
            right_col_charge,
            y,
            f"{task.effort_days} j",
            va="center",
            ha="left",
            fontsize=10,
            color="#111827",
            fontweight="bold",
        )
        ax.text(
            right_col_deliverable,
            y,
            task.deliverable,
            va="center",
            ha="left",
            fontsize=9,
            color="#475569",
        )

    milestone_y = -1.1
    ax.scatter(
        [milestone_num],
        [milestone_y],
        marker="D",
        s=120,
        color="#111827",
        zorder=5,
    )
    ax.text(
        start_num,
        milestone_y,
        f"Jalon : {format_date_fr(milestone_date)}",
        va="center",
        ha="left",
        fontsize=10,
        color="#111827",
        fontweight="bold",
    )
    ax.text(
        right_col_charge,
        milestone_y,
        "0 j",
        va="center",
        ha="left",
        fontsize=10,
        color="#111827",
        fontweight="bold",
    )
    ax.text(
        right_col_deliverable,
        milestone_y,
        "Remise finale du projet",
        va="center",
        ha="left",
        fontsize=9,
        color="#475569",
    )

    ax.set_xlim(start_num - 1.5, milestone_num + 23)
    ax.set_ylim(-1.9, task_count - 0.3)
    ax.set_yticks(y_positions + [milestone_y])
    ax.set_yticklabels([task.name for task in tasks] + [""], fontsize=10)

    tick_positions = [mdates.date2num(tick) for tick in tick_dates]
    tick_labels = [format_date_fr(tick).replace(" 2026", "") for tick in tick_dates]
    ax.set_xticks(tick_positions)
    ax.set_xticklabels(tick_labels, fontsize=9, fontweight="bold")

    ax.tick_params(axis="x", length=0, colors="#334155", rotation=0)
    ax.tick_params(axis="y", length=0, pad=8)

    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.grid(axis="x", color="#CBD5E1", linestyle="--", linewidth=0.8, alpha=0.65)
    ax.grid(axis="y", visible=False)

    ax.text(
        start_num,
        task_count + 0.45,
        "Diagramme de Gantt - Gestion du projet d'imagerie medicale",
        fontsize=20,
        fontweight="bold",
        color="#0F172A",
        ha="left",
    )
    ax.text(
        start_num,
        task_count + 0.05,
        f"Debut du projet : {format_date_fr(project_start)} | Jalon final : {format_date_fr(milestone_date)}",
        fontsize=11,
        color="#475569",
        ha="left",
    )
    ax.text(
        start_num,
        task_count - 0.35,
        f"Charge estimee totale : {total_effort} jours ouvres. Le planning met en avant une gestion realiste et progressive du projet.",
        fontsize=10,
        color="#64748B",
        ha="left",
    )

    ax.text(right_col_charge, task_count - 0.95, "Charge", fontsize=10, fontweight="bold", color="#0F172A")
    ax.text(
        right_col_deliverable,
        task_count - 0.95,
        "Livrable principal",
        fontsize=10,
        fontweight="bold",
        color="#0F172A",
    )

    legend_handles = [Patch(facecolor=PHASE_COLORS[phase], edgecolor="none", label=phase) for phase in PHASE_ORDER]
    legend_handles.append(Patch(facecolor="#111827", edgecolor="none", label="Jalon"))
    ax.legend(
        handles=legend_handles,
        loc="lower right",
        frameon=False,
        ncol=3,
        fontsize=9,
        bbox_to_anchor=(1.0, -0.11),
    )

    ax.text(
        start_num,
        -1.65,
        "Lecture : les barres representent les periodes actives, la colonne Charge correspond au temps de travail estime.",
        fontsize=9,
        color="#64748B",
        ha="left",
    )

    plt.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate a PNG Gantt chart for the medical imaging project.")
    parser.add_argument("--output", type=Path, required=True, help="Output PNG path.")
    parser.add_argument(
        "--start-date",
        type=parse_date,
        default=PROJECT_START,
        help="Project start date in YYYY-MM-DD format.",
    )
    parser.add_argument(
        "--milestone-date",
        type=parse_date,
        default=MILESTONE_DATE,
        help="Milestone date in YYYY-MM-DD format.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    build_chart(
        output_path=args.output,
        project_start=args.start_date,
        milestone_date=args.milestone_date,
    )
    print(args.output)


if __name__ == "__main__":
    main()
