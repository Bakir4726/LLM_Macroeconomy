Place ici les exports officiels ou les documents que tu veux indexer sans modifier le code.

Exemples :

- `all_ECB_speeches.csv`
- pages HTML sauvegardees depuis le site de la BCE
- notes internes converties en `.txt`
- articles ou PDFs convertis en texte `.pdf.txt`

Les fichiers de ce dossier sont ignores par Git sauf ce README.
