---
title: Comptes rendus BCE et guidage de politique monétaire
url: https://www.ecb.europa.eu/press/accounts/html/index.en.html
source_label: ECB monetary policy accounts
theme: politique_monétaire
---

# Comptes rendus BCE et guidage de politique monétaire

Les comptes rendus de la BCE servent à comprendre le ton du conseil des gouverneurs au-delà de la décision de taux. Ils permettent de savoir si le débat porte surtout sur la persistance de l'inflation, la faiblesse de la demande, les risques extérieurs ou la transmission des conditions financières.

Pour une direction financière, la bonne lecture consiste à séparer :

- le message sur l'inflation sous-jacente,
- le message sur les salaires et les services,
- le message sur le crédit et la transmission monétaire,
- le message sur les risques de croissance.

Quand les comptes rendus insistent sur la prudence et la dépendance aux données, cela signifie souvent qu'il faut éviter de surinterpréter une seule publication. La trajectoire de financement doit alors rester conditionnelle aux prochaines données sur les prix, l'emploi et le crédit.

Source officielle à privilégier : les monetary policy accounts de la BCE, complétés par les discours des membres du conseil et par le portail de données BCE pour les séries.
