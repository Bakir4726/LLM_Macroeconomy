# Transmission monétaire et coût du financement

La politique monétaire agit sur l'économie réelle via plusieurs canaux. Pour une PME, les plus visibles sont le coût du crédit, les conditions bancaires, la demande finale et les anticipations des clients et fournisseurs.

Quand la banque centrale maintient un ton restrictif, la transmission passe souvent par :

- une hausse du coût du refinancement,
- un durcissement des standards de crédit,
- un ralentissement de la demande à mesure que les ménages et les entreprises reportent certaines dépenses,
- une modération progressive de l'inflation.

Un message de prudence sur les prix ne signifie pas automatiquement qu'un nouveau tour de vis est imminent. Il peut aussi signaler que la banque centrale veut garder des conditions financières serrées pendant plus longtemps, même si la croissance ralentit.

Pour une entreprise, les questions à surveiller sont :

- la vitesse de repli de l'inflation sous-jacente,
- la dynamique des salaires,
- le niveau des taux d'emprunt aux entreprises,
- la sensibilité du carnet de commandes à la demande intérieure et aux exportations.

Un régime de resserrement financier prolongé plaide en général pour :

- privilégier les investissements à retour rapide,
- conserver une marge de liquidité,
- renégocier le passif à l'avance,
- calibrer les recrutements sur le rythme de la demande effective.
