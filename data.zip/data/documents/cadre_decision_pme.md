# Cadre de décision pour PME de la zone euro

Une PME n'a pas besoin d'un commentaire macro générique. Elle a besoin d'une grille de lecture orientée décision.

Questions utiles :

- puis-je ajuster mes prix sans casser la demande ?
- mon prochain investissement doit-il être accéléré, étalé ou reporté ?
- faut-il verrouiller un financement avant un possible nouveau resserrement ?
- dois-je recruter tout de suite ou garder de la flexibilité ?

Règles simples :

- inflation élevée + demande solide = revue sélective des prix et protection des marges ;
- inflation en baisse + financement encore cher = discipline sur le capex et priorité à la trésorerie ;
- demande molle + coût du travail en hausse = embauches par étapes et focalisation sur la productivité ;
- baisse de l'incertitude + coût du financement en repli = fenêtre plus favorable pour investir.

Le chatbot doit donc produire quatre objets à chaque réponse :

1. un diagnostic macro,
2. le narratif dominant,
3. le niveau de risque,
4. une traduction en actions pour la tarification, l'investissement, le financement et le recrutement.
