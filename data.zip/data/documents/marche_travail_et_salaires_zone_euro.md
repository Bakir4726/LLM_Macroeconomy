---
title: Marché du travail et salaires dans la zone euro
url: https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Unemployment_statistics
source_label: Eurostat labour market
theme: emploi
---

# Marché du travail et salaires dans la zone euro

Le marché du travail reste un signal clé pour juger la persistance de l'inflation dans les services. Un chômage bas peut soutenir les négociations salariales, même lorsque l'énergie se calme et que l'inflation globale ralentit.

Pour les entreprises, la lecture utile n'est pas seulement le taux de chômage. Il faut aussi regarder :

- la difficulté de recrutement,
- la pression sur les salaires de base,
- la capacité à répercuter les coûts dans les prix,
- l'écart entre la demande finale et les besoins de main-d'oeuvre.

Si l'emploi reste résilient alors que la croissance ralentit, la productivité et la flexibilité du recrutement deviennent plus importantes que le simple volume d'embauches.

Source officielle à suivre : Eurostat pour le marché du travail, complété si besoin par les tableaux salariaux publiés par la BCE et la Commission européenne.
