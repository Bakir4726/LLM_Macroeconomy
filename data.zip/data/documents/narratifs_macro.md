# Narratifs macro à suivre

Dans un chatbot économique, les narratifs servent à relier le langage des institutions aux mécanismes économiques.

Narratifs fréquents :

- désinflation graduelle,
- inflation persistante dans les services,
- choc énergie,
- faiblesse industrielle,
- résilience du marché du travail,
- resserrement financier,
- incertitude géopolitique,
- ralentissement de la demande.

Un narratif n'est pas seulement un mot-clé. C'est une combinaison cohérente de signaux. Par exemple :

- "choc énergie" renvoie à la volatilité des prix, au risque sur les marges, à l'effet sur les prix de vente et à l'incertitude de court terme ;
- "faiblesse de la demande" renvoie à des carnets plus mous, à une croissance atone, à un arbitrage sur les recrutements et à une sensibilité accrue aux promotions ;
- "résilience du marché du travail" suggère que l'emploi tient mieux que l'activité, ce qui soutient le revenu mais peut maintenir une pression salariale.

L'intérêt analytique est de transformer ces narratifs en alertes business :

- risque de financement,
- risque de marge,
- risque de stock,
- risque de demande,
- risque RH.
