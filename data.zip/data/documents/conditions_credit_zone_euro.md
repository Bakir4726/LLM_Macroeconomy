---
title: Conditions de crédit dans la zone euro
url: https://www.ecb.europa.eu/stats/ecb_surveys/bank_lending_survey/html/index.en.html
source_label: ECB Bank Lending Survey
theme: financement
---

# Conditions de crédit dans la zone euro

Le Bank Lending Survey de la BCE est utile pour lire l'offre de crédit avant que les effets ne soient visibles dans les comptes d'exploitation des entreprises. Quand les banques durcissent leurs critères, les PME subissent souvent un double choc : des marges de négociation plus faibles et des délais de financement plus longs.

Pour une PME, il faut distinguer trois questions :

- le niveau des taux servis,
- l'appétit des banques pour le risque,
- la qualité des garanties ou covenants demandés.

Un simple reflux de l'inflation ne suffit pas à détendre rapidement le financement. Si les critères de prêt restent stricts, il faut privilégier la trésorerie, prioriser les projets à retour rapide et renégocier les besoins de liquidité plus tôt dans le cycle.

Source officielle à consulter en priorité : la BCE, via le Bank Lending Survey, pour suivre les conditions de crédit, la demande de prêt et les changements de standards bancaires.
