---
title: Demande et confiance des entreprises
url: https://economy-finance.ec.europa.eu/economic-forecast-and-surveys/business-and-consumer-surveys_en
source_label: European Commission business surveys
theme: demande
---

# Demande et confiance des entreprises

La Commission européenne publie des enquêtes de conjoncture utiles pour relier le discours macro à la réalité micro des entreprises. Quand la demande ralentit, les entreprises perdent du pouvoir de tarification avant même que les indicateurs agrégés ne se retournent fortement.

Pour une PME, ces enquêtes aident à lire :

- l'orientation des carnets de commandes,
- le niveau des stocks,
- les contraintes d'offre encore présentes,
- la confiance des menages et des industriels.

Une demande faible avec coûts encore hauts est un régime délicat : la marge se défend moins par la hausse de prix que par la sélectivité commerciale, le pilotage des volumes et la priorisation des investissements.

Source officielle utile : les Business and Consumer Surveys de la Commission pour suivre la demande, la confiance et les signaux précoces de retournement.
