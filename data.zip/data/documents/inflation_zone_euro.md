# Inflation dans la zone euro

L'inflation de la zone euro doit être lue en séparant plusieurs moteurs :

- l'énergie et les matières premières,
- les prix alimentaires,
- les services,
- les salaires,
- la demande domestique.

Une désinflation crédible apparaît lorsque les chocs d'offre se dissipent, que les goulets d'étranglement se normalisent et que la demande ne surchauffe plus. En revanche, si les salaires restent très dynamiques dans les services, l'inflation sous-jacente peut ralentir seulement de façon graduelle.

Pour une PME, l'enjeu n'est pas seulement de savoir si l'inflation baisse. Il faut identifier si le risque dominant vient :

- d'un choc énergie qui comprime les marges,
- d'une pression salariale qui augmente les coûts fixes,
- d'une demande encore solide qui permet de répercuter les prix,
- ou d'une faiblesse de la demande qui limite le pouvoir de tarification.

Quand le narratif dominant est "désinflation graduelle", la bonne lecture n'est pas une disparition du risque. Cela signifie plutôt que le rythme de hausse des prix ralentit, mais qu'un pilotage fin des prix et des achats reste nécessaire.
