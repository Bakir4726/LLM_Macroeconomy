from __future__ import annotations

from .models import BusinessScenario, MacroSnapshot, NarrativeSignal
from .retrieval import tokenize
from .text_utils import normalize_for_matching

NARRATIVE_LEXICONS: dict[str, list[str]] = {
    "désinflation graduelle": [
        "désinflation",
        "desinflation",
        "inflation slows",
        "price pressures easing",
        "inflation receding",
        "modération des prix",
    ],
    "choc énergie": [
        "énergie",
        "energie",
        "energy",
        "oil",
        "gas",
        "commodity",
        "supply shock",
    ],
    "faiblesse de la demande": [
        "weak demand",
        "slowdown",
        "soft orders",
        "faible demande",
        "consumption slowdown",
        "industrial weakness",
    ],
    "tension salariale": [
        "wage",
        "salary",
        "labour cost",
        "services inflation",
        "pression salariale",
    ],
    "resserrement financier": [
        "tightening",
        "credit conditions",
        "borrowing cost",
        "financial tightening",
        "conditions de crédit",
        "conditions de credit",
    ],
    "résilience du marché du travail": [
        "labour market resilience",
        "employment remains strong",
        "low unemployment",
        "marché du travail",
        "marche du travail",
        "job growth",
    ],
    "incertitude géopolitique": [
        "uncertainty",
        "geopolitical",
        "trade tension",
        "risk",
        "volatility",
        "incertitude",
    ],
}

UNCERTAINTY_TERMS = {
    "uncertainty",
    "risk",
    "volatile",
    "volatility",
    "shock",
    "tightening",
    "slowdown",
    "recession",
    "stress",
    "fragile",
    "incertitude",
    "choc",
    "tension",
    "prudence",
}


def detect_narratives(text: str, limit: int = 4) -> list[NarrativeSignal]:
    normalized_text = normalize_for_matching(text)
    signals: list[NarrativeSignal] = []
    for name, keywords in NARRATIVE_LEXICONS.items():
        evidence_terms = [term for term in keywords if normalize_for_matching(term) in normalized_text]
        if not evidence_terms:
            continue
        score = round((len(evidence_terms) / len(keywords)) * 100, 1)
        signals.append(NarrativeSignal(name=name, score=score, evidence_terms=evidence_terms[:3]))

    signals.sort(key=lambda item: item.score, reverse=True)
    return signals[:limit]


def compute_uncertainty_score(text: str) -> float:
    tokens = tokenize(text)
    if not tokens:
        return 0.0
    hits = sum(1 for token in tokens if token in UNCERTAINTY_TERMS)
    density = hits / len(tokens)
    return round(min(100.0, density * 1400), 1)


def build_business_scenario(
    snapshot: dict[str, MacroSnapshot],
    narratives: list[NarrativeSignal],
    uncertainty_score: float,
) -> BusinessScenario:
    hicp = snapshot.get("hicp")
    core = snapshot.get("core_inflation")
    gdp = snapshot.get("gdp_growth")
    unemployment = snapshot.get("unemployment_rate")
    borrowing = snapshot.get("borrowing_cost")
    wage = snapshot.get("wage_growth")

    narrative_names = {item.name for item in narratives}

    inflation_summary = "inflation en voie de normalisation"
    if hicp and core:
        if hicp.latest_value > 2.5 or core.latest_value > 2.8:
            inflation_summary = "inflation encore au-dessus d'une zone de confort"
        elif hicp.trend == "down" and core.trend == "down":
            inflation_summary = "désinflation progressive mais incomplète"

    growth_summary = "croissance molle"
    if gdp and gdp.latest_value >= 0.3:
        growth_summary = "croissance modeste mais plus constructive"
    elif gdp and gdp.latest_value <= 0.1:
        growth_summary = "croissance très faible"

    labour_summary = "marché du travail encore solide"
    if unemployment and unemployment.latest_value >= 6.6:
        labour_summary = "marché du travail plus fragile"

    summary = (
        f"Scénario à 1-2 trimestres : {inflation_summary}, {growth_summary}, "
        f"{labour_summary}, avec un score d'incertitude de {uncertainty_score}/100."
    )

    pricing = "Maintenir une revue sélective des prix et suivre les coûts salariaux."
    if "choc énergie" in narrative_names:
        pricing = "Prioriser des clauses d'indexation partielle et protéger les marges énergie."
    elif "faiblesse de la demande" in narrative_names:
        pricing = "Éviter des hausses généralisées ; privilégier des ajustements ciblés par segment."

    investment = "Conserver les projets à retour rapide et étaler le capex non essentiel."
    if gdp and gdp.latest_value >= 0.3 and uncertainty_score < 20:
        investment = "Fenêtre plus favorable pour accélérer les investissements productifs."

    financing = "Sécuriser la liquidité et renégocier les lignes avant tout nouveau stress de taux."
    if borrowing and borrowing.latest_value < 4.0 and borrowing.trend == "down":
        financing = "Le coût du financement se détend lentement ; sonder le marché pour refinancer."
    if "resserrement financier" in narrative_names:
        financing = "Traiter le financement comme priorité de court terme et verrouiller les marges de liquidité."

    hiring = "Étaler les recrutements et prioriser les rôles critiques."
    if "résilience du marché du travail" in narrative_names and uncertainty_score < 20:
        hiring = "Le marché du travail reste solide ; recruter de façon ciblée sur les fonctions rares."
    if gdp and gdp.latest_value <= 0.1:
        hiring = "Ralentir les embauches discrétionnaires et suivre la productivité par équipe."

    watchlist = [
        "inflation HICP et inflation sous-jacente",
        "coût du financement des entreprises",
        "salaires nominaux et services",
        "croissance / commandes / confiance",
    ]
    if wage and wage.latest_value > 4.0:
        watchlist.append("risque de second tour via les salaires")

    return BusinessScenario(
        summary=summary,
        pricing=pricing,
        investment=investment,
        financing=financing,
        hiring=hiring,
        watchlist=watchlist,
    )
