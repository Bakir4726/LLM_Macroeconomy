from __future__ import annotations

import unicodedata

ENCODING_CANDIDATES = ("utf-8", "utf-8-sig", "cp1252", "latin-1")
MOJIBAKE_MARKERS = ("Ã", "Â", "â€", "â€™", "â€“", "â€”", "œ", "�")


def decode_text_bytes(raw: bytes) -> str:
    decoded: str | None = None
    for encoding in ENCODING_CANDIDATES:
        try:
            decoded = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue

    if decoded is None:
        decoded = raw.decode("utf-8", errors="replace")

    return clean_text(decoded)


def clean_text(value: str) -> str:
    normalized = value.replace("\ufeff", "").replace("\x00", "")
    return _repair_mojibake(normalized)


def normalize_for_matching(value: str) -> str:
    cleaned = clean_text(value).casefold()
    decomposed = unicodedata.normalize("NFKD", cleaned)
    return "".join(char for char in decomposed if not unicodedata.combining(char))


def _repair_mojibake(value: str) -> str:
    if not any(marker in value for marker in MOJIBAKE_MARKERS):
        return value

    for encoding in ("cp1252", "latin-1"):
        try:
            repaired = value.encode(encoding).decode("utf-8")
        except UnicodeError:
            continue
        if repaired.count("�") <= value.count("�"):
            return repaired

    return value
