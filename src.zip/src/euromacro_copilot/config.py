from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _load_env_file(env_file: Path) -> None:
    if not env_file.exists():
        return

    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


@dataclass(frozen=True)
class Settings:
    project_root: Path
    documents_dir: Path
    external_dir: Path
    series_file: Path
    cache_dir: Path
    top_k: int
    chunk_size: int
    llm_provider: str
    llm_api_base: str
    llm_api_key: str | None
    llm_model: str
    ollama_api_base: str
    ollama_model: str
    request_timeout: int = 30

    @classmethod
    def from_project_root(cls, project_root: Path | None = None) -> "Settings":
        root = (project_root or Path(__file__).resolve().parents[2]).resolve()
        _load_env_file(root / ".env")

        cache_dir = root / "data" / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cls(
            project_root=root,
            documents_dir=root / "data" / "documents",
            external_dir=root / "data" / "external",
            series_file=root / "data" / "series" / "euro_macro_demo.csv",
            cache_dir=cache_dir,
            top_k=int(os.getenv("EMC_TOP_K", "4")),
            chunk_size=int(os.getenv("EMC_CHUNK_SIZE", "900")),
            llm_provider=os.getenv("LLM_PROVIDER", "auto").strip().lower(),
            llm_api_base=os.getenv("LLM_API_BASE", "https://api.openai.com/v1").rstrip("/"),
            llm_api_key=os.getenv("LLM_API_KEY"),
            llm_model=os.getenv("LLM_MODEL", "gpt-4o-mini").strip(),
            ollama_api_base=os.getenv("OLLAMA_API_BASE", "http://127.0.0.1:11434").rstrip("/"),
            ollama_model=os.getenv("OLLAMA_MODEL", "mistral:latest").strip(),
            request_timeout=int(os.getenv("EMC_REQUEST_TIMEOUT", "45")),
        )
