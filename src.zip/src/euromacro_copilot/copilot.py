from __future__ import annotations

from pathlib import Path

from .analytics import build_business_scenario, compute_uncertainty_score, detect_narratives
from .config import Settings
from .documents import load_documents
from .llm import BaseChatClient, build_chat_client
from .macro_data import MacroStore
from .models import ChatResponse, Chunk, DocumentReference, MacroSnapshot, NarrativeSignal
from .retrieval import TfidfRetriever


class EuroMacroCopilot:
    def __init__(
        self,
        settings: Settings,
        retriever: TfidfRetriever,
        macro_store: MacroStore,
        llm_client: BaseChatClient,
    ):
        self.settings = settings
        self.retriever = retriever
        self.macro_store = macro_store
        self.llm_client = llm_client

    @classmethod
    def from_project_root(cls, project_root: Path | None = None) -> "EuroMacroCopilot":
        settings = Settings.from_project_root(project_root)
        documents = load_documents(settings.documents_dir, settings.external_dir)
        retriever = TfidfRetriever.from_documents(documents, chunk_size=settings.chunk_size)
        macro_store = MacroStore.from_csv(settings.series_file)
        llm_client = build_chat_client(settings)
        return cls(settings=settings, retriever=retriever, macro_store=macro_store, llm_client=llm_client)

    @property
    def corpus_size(self) -> int:
        return len(self.retriever.chunks)

    def dashboard_state(self) -> dict[str, object]:
        snapshot = self.macro_store.latest_snapshot()
        corpus_text = self.retriever.full_corpus_text()
        narratives = detect_narratives(corpus_text, limit=5)
        uncertainty = compute_uncertainty_score(corpus_text)
        library = self.document_library()
        return {
            "snapshot": snapshot,
            "narratives": narratives,
            "uncertainty_score": uncertainty,
            "documents_indexed": self.corpus_size,
            "documents_available": len(library),
            "llm_provider": self.llm_client.provider_name,
        }

    def document_library(self, limit: int | None = None) -> list[DocumentReference]:
        documents = _build_document_references(self.retriever.chunks, limit=None)
        documents.sort(key=lambda item: (item.source_type, item.title.casefold()))
        if limit is not None:
            return documents[:limit]
        return documents

    def answer(
        self,
        question: str,
        top_k: int | None = None,
        conversation: list[dict[str, str]] | None = None,
    ) -> ChatResponse:
        result_count = top_k or self.settings.top_k
        candidate_chunks = self.retriever.search(question, max(result_count * 3, 8))
        evidence = candidate_chunks[:result_count]
        evidence_doc_ids = {chunk.doc_id for chunk in evidence}
        documents = _build_document_references(
            candidate_chunks,
            limit=max(result_count + 2, 4),
            evidence_doc_ids=evidence_doc_ids,
        )
        context_text = "\n\n".join(chunk.text for chunk in evidence) or self.retriever.full_corpus_text()
        snapshot = self.macro_store.latest_snapshot()
        narratives = detect_narratives(context_text, limit=4)
        uncertainty_score = compute_uncertainty_score(context_text)
        scenario = build_business_scenario(snapshot, narratives, uncertainty_score)

        answer = self._generate_answer(
            question=question,
            evidence=evidence,
            documents=documents,
            snapshot=snapshot,
            narratives=narratives,
            uncertainty_score=uncertainty_score,
            scenario=scenario,
            conversation=conversation or [],
        )
        return ChatResponse(
            question=question,
            answer=answer,
            evidence=evidence,
            documents=documents,
            snapshot=snapshot,
            narratives=narratives,
            uncertainty_score=uncertainty_score,
            scenario=scenario,
        )

    def _generate_answer(
        self,
        question: str,
        evidence: list[Chunk],
        documents: list[DocumentReference],
        snapshot: dict[str, MacroSnapshot],
        narratives: list[NarrativeSignal],
        uncertainty_score: float,
        scenario,
        conversation: list[dict[str, str]],
    ) -> str:
        llm_answer = self.llm_client.chat(
            system_prompt=_system_prompt(),
            user_prompt=_user_prompt(
                question=question,
                evidence=evidence,
                documents=documents,
                snapshot=snapshot,
                narratives=narratives,
                uncertainty_score=uncertainty_score,
                scenario=scenario,
                conversation=conversation,
            ),
        )
        if llm_answer:
            return _append_grounding_sections(llm_answer, evidence, documents)
        fallback = _fallback_answer(question, evidence, snapshot, narratives, uncertainty_score, scenario)
        return _append_grounding_sections(fallback, evidence, documents)


def _system_prompt() -> str:
    return (
        "You are EuroMacro Copilot, a specialized assistant for euro area macroeconomics. "
        "You answer in French. Be rigorous, explicit, and useful for SMEs, CFO teams, and strategy teams. "
        "Base your reasoning on the provided macro snapshot, detected narratives, scenario, and evidence identifiers. "
        "Do not invent sources or figures. If the evidence is weak, say so clearly. "
        "Use the evidence identifiers like [S1] when you make factual claims. "
        "Structure the answer with these exact sections: Diagnostic, Implications PME, Variables a surveiller. "
        "Do not add a Sources section or a Documents section."
    )


def _user_prompt(
    question: str,
    evidence: list[Chunk],
    documents: list[DocumentReference],
    snapshot: dict[str, MacroSnapshot],
    narratives: list[NarrativeSignal],
    uncertainty_score: float,
    scenario,
    conversation: list[dict[str, str]],
) -> str:
    evidence_lines = []
    for index, chunk in enumerate(evidence, start=1):
        source_name = Path(chunk.source).name if chunk.source else chunk.source_type
        url = chunk.url or "n/a"
        evidence_lines.append(
            f"- [S{index}] {chunk.title} | type={chunk.source_type} | source={source_name} "
            f"| url={url} | score={chunk.score:.3f} | extrait={_compact_excerpt(chunk.text, 450)}"
        )

    snapshot_lines = []
    for item in snapshot.values():
        delta = f"{item.delta:+.1f}" if item.delta is not None else "n/a"
        snapshot_lines.append(
            f"- {item.label}: {item.latest_value:.1f} {item.unit} on {item.latest_date.isoformat()} (delta {delta})"
        )

    narrative_lines = [f"- {item.name}: {item.score:.1f}" for item in narratives]

    conversation_lines = []
    for turn in conversation[-6:]:
        role = turn.get("role", "user")
        content = (turn.get("content") or "").strip()
        if not content:
            continue
        conversation_lines.append(f"- {role}: {content}")

    document_lines = []
    for index, document in enumerate(documents, start=1):
        source_name = Path(document.source).name if document.source else document.source_type
        url = document.url or "n/a"
        document_lines.append(
            f"- [D{index}] {document.title} | type={document.source_type} | source={source_name} "
            f"| url={url} | score={document.score:.3f} | resume={_compact_excerpt(document.excerpt, 220)}"
        )

    return (
        f"Conversation récente:\n{chr(10).join(conversation_lines) or '- none'}\n\n"
        f"Question actuelle:\n{question}\n\n"
        f"Macro snapshot:\n{chr(10).join(snapshot_lines)}\n\n"
        f"Narratives:\n{chr(10).join(narrative_lines) or '- none'}\n\n"
        f"Uncertainty score: {uncertainty_score}/100\n\n"
        f"Scenario summary:\n{scenario.summary}\n"
        f"Tarification: {scenario.pricing}\n"
        f"Investment: {scenario.investment}\n"
        f"Financing: {scenario.financing}\n"
        f"Hiring: {scenario.hiring}\n"
        f"Watchlist: {'; '.join(scenario.watchlist)}\n\n"
        f"Evidence:\n{chr(10).join(evidence_lines) or '- no document evidence'}\n\n"
        f"Documents complémentaires:\n{chr(10).join(document_lines) or '- none'}\n\n"
        "Instructions:\n"
        "- Répondre en français clair.\n"
        "- Rester concis mais plus utile qu'une simple synthèse.\n"
        "- S'appuyer sur les chiffres et narratifs fournis.\n"
        "- Citer les identifiants [S1], [S2], etc. dans le texte quand tu t'appuies sur une preuve.\n"
        "- Formuler des implications concrètes pour une PME.\n"
        "- Si la preuve est faible ou contradictoire, le dire explicitement."
    )


def _fallback_answer(
    question: str,
    evidence: list[Chunk],
    snapshot: dict[str, MacroSnapshot],
    narratives: list[NarrativeSignal],
    uncertainty_score: float,
    scenario,
) -> str:
    hicp = snapshot.get("hicp")
    core = snapshot.get("core_inflation")
    borrowing = snapshot.get("borrowing_cost")
    gdp = snapshot.get("gdp_growth")

    diagnostic_bits = []
    if hicp:
        diagnostic_bits.append(
            f"L'inflation globale ressort à {_fr_number(hicp.latest_value)} % ({_trend_label(hicp.trend)}) sur la dernière observation."
        )
    if core:
        diagnostic_bits.append(
            f"L'inflation sous-jacente ressort à {_fr_number(core.latest_value)} % ({_trend_label(core.trend)}), ce qui reste le meilleur test de persistance."
        )
    if borrowing:
        diagnostic_bits.append(
            f"Le coût du financement des entreprises est à {_fr_number(borrowing.latest_value)} % et reste une contrainte importante."
        )
    if gdp:
        diagnostic_bits.append(
            f"La croissance de démonstration s'établit à {_fr_number(gdp.latest_value)} % en glissement trimestriel, dans un régime encore modeste."
        )

    top_narratives = ", ".join(item.name for item in narratives) or "aucun narratif saillant"
    source_titles = ", ".join(dict.fromkeys(chunk.title for chunk in evidence)) or "corpus local"
    watchlist = "; ".join(scenario.watchlist)

    return (
        "### Diagnostic\n"
        f"{' '.join(diagnostic_bits)} "
        f"Les narratifs dominants dans le corpus mobilisé sont : {top_narratives}. "
        f"Le score d'incertitude ressort à {_fr_number(uncertainty_score)}/100. "
        f"Les points les mieux documentés proviennent de {source_titles}.\n\n"
        "### Implications PME\n"
        f"{scenario.summary} "
        f"Tarification : {scenario.pricing} "
        f"Investissement : {scenario.investment} "
        f"Financement : {scenario.financing} "
        f"Recrutement : {scenario.hiring}\n\n"
        "### Variables à surveiller\n"
        f"{watchlist}\n\n"
        f"Question analysée : {question}"
    )


def _fr_number(value: float) -> str:
    return f"{value:.1f}".replace(".", ",")


def _trend_label(value: str) -> str:
    return {
        "up": "hausse",
        "down": "baisse",
        "flat": "stabilité",
    }.get(value, value)


def _append_grounding_sections(
    answer: str,
    evidence: list[Chunk],
    documents: list[DocumentReference],
) -> str:
    source_lines = []
    for index, chunk in enumerate(evidence, start=1):
        source_name = Path(chunk.source).name if chunk.source else chunk.source_type
        excerpt = _compact_excerpt(chunk.text, 180)
        url_part = f" | lien: {chunk.url}" if chunk.url else ""
        source_lines.append(
            f"- [S{index}] {chunk.title} | {source_name} | type: {chunk.source_type} | score: {chunk.score:.2f}{url_part} | extrait: {excerpt}"
        )

    document_lines = []
    for index, document in enumerate(documents, start=1):
        source_name = Path(document.source).name if document.source else document.source_type
        excerpt = _compact_excerpt(document.excerpt, 150)
        url_part = f" | lien: {document.url}" if document.url else ""
        document_lines.append(
            f"- [D{index}] {document.title} | {source_name} | type: {document.source_type} | score: {document.score:.2f}{url_part} | focus: {excerpt}"
        )

    sections = [answer.strip()]
    sections.append("### Sources")
    sections.append("\n".join(source_lines) or "- Aucune source textuelle pertinente")
    sections.append("### Documents complémentaires")
    sections.append("\n".join(document_lines) or "- Aucun document complémentaire")
    return "\n\n".join(section for section in sections if section.strip())


def _build_document_references(
    chunks: list[Chunk],
    limit: int | None,
    evidence_doc_ids: set[str] | None = None,
) -> list[DocumentReference]:
    grouped: dict[str, DocumentReference] = {}
    for chunk in chunks:
        existing = grouped.get(chunk.doc_id)
        excerpt = _compact_excerpt(chunk.text, 220)
        if existing is None or chunk.score > existing.score:
            grouped[chunk.doc_id] = DocumentReference(
                doc_id=chunk.doc_id,
                title=chunk.title,
                source=chunk.source,
                source_type=chunk.source_type,
                url=chunk.url,
                metadata=chunk.metadata,
                score=chunk.score,
                excerpt=excerpt,
            )

    ordered = list(grouped.values())
    priority_docs = evidence_doc_ids or set()
    ordered.sort(
        key=lambda item: (
            item.doc_id in priority_docs,
            -item.score,
            item.title.casefold(),
        )
    )
    if limit is not None:
        return ordered[:limit]
    return ordered


def _compact_excerpt(text: str, limit: int) -> str:
    compact = " ".join(text.split())
    if len(compact) <= limit:
        return compact
    return compact[: max(limit - 1, 1)].rstrip() + "..."
