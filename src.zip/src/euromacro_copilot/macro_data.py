from __future__ import annotations

import csv
import io
from collections import defaultdict
from datetime import date
from pathlib import Path

from .models import MacroPoint, MacroSnapshot
from .text_utils import decode_text_bytes


class MacroStore:
    def __init__(self, series: dict[str, list[MacroPoint]]):
        self.series = {
            indicator: sorted(points, key=lambda item: item.point_date)
            for indicator, points in series.items()
        }

    @classmethod
    def from_csv(cls, path: Path) -> "MacroStore":
        series: dict[str, list[MacroPoint]] = defaultdict(list)
        decoded = decode_text_bytes(path.read_bytes())
        with io.StringIO(decoded, newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                point = MacroPoint(
                    indicator=row["indicator"],
                    label=row["label"],
                    point_date=date.fromisoformat(row["date"]),
                    value=float(row["value"]),
                    unit=row["unit"],
                    frequency=row["frequency"],
                    source=row["source"],
                )
                series[point.indicator].append(point)
        return cls(dict(series))

    def latest_snapshot(self) -> dict[str, MacroSnapshot]:
        snapshots: dict[str, MacroSnapshot] = {}
        for indicator, points in self.series.items():
            latest = points[-1]
            previous = points[-2] if len(points) > 1 else None
            delta = latest.value - previous.value if previous else None
            trend = "flat"
            if delta is not None:
                if delta > 0.05:
                    trend = "up"
                elif delta < -0.05:
                    trend = "down"
            snapshots[indicator] = MacroSnapshot(
                indicator=indicator,
                label=latest.label,
                latest_date=latest.point_date,
                latest_value=latest.value,
                previous_value=previous.value if previous else None,
                delta=delta,
                unit=latest.unit,
                source=latest.source,
                trend=trend,
            )
        return snapshots

    def chart_rows(self, indicator: str) -> list[dict[str, object]]:
        points = self.series.get(indicator, [])
        return [
            {"date": point.point_date.isoformat(), "value": point.value, "label": point.label}
            for point in points
        ]

    def available_indicators(self) -> list[str]:
        return sorted(self.series.keys())
