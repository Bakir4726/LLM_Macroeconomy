from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any


@dataclass(frozen=True)
class Document:
    doc_id: str
    title: str
    body: str
    source: str
    source_type: str
    url: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    doc_id: str
    title: str
    text: str
    source: str
    source_type: str
    url: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    score: float = 0.0


@dataclass(frozen=True)
class DocumentReference:
    doc_id: str
    title: str
    source: str
    source_type: str
    url: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    score: float = 0.0
    excerpt: str = ""


@dataclass(frozen=True)
class MacroPoint:
    indicator: str
    label: str
    point_date: date
    value: float
    unit: str
    frequency: str
    source: str


@dataclass(frozen=True)
class MacroSnapshot:
    indicator: str
    label: str
    latest_date: date
    latest_value: float
    previous_value: float | None
    delta: float | None
    unit: str
    source: str
    trend: str


@dataclass(frozen=True)
class NarrativeSignal:
    name: str
    score: float
    evidence_terms: list[str]


@dataclass(frozen=True)
class BusinessScenario:
    summary: str
    pricing: str
    investment: str
    financing: str
    hiring: str
    watchlist: list[str]


@dataclass(frozen=True)
class ChatResponse:
    question: str
    answer: str
    evidence: list[Chunk]
    documents: list[DocumentReference]
    snapshot: dict[str, MacroSnapshot]
    narratives: list[NarrativeSignal]
    uncertainty_score: float
    scenario: BusinessScenario
