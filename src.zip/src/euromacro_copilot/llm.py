from __future__ import annotations

import json
from typing import Any
from urllib import error, request

from .config import Settings


class BaseChatClient:
    provider_label = "heuristic"

    @property
    def is_configured(self) -> bool:
        return False

    @property
    def provider_name(self) -> str:
        return self.provider_label

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str | None:
        return None


class OpenAICompatibleClient(BaseChatClient):
    provider_label = "openai-compatible"

    def __init__(self, api_base: str, api_key: str | None, model: str, timeout: int = 30):
        self.api_base = api_base.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key and self.model)

    @property
    def provider_name(self) -> str:
        return f"{self.provider_label}:{self.model}" if self.model else self.provider_label

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str | None:
        if not self.is_configured:
            return None

        payload = {
            "model": self.model,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        raw = _post_json(
            url=f"{self.api_base}/chat/completions",
            payload=payload,
            timeout=self.timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
        )
        if raw is None:
            return None

        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return None
        return _extract_openai_message(parsed)


class OllamaClient(BaseChatClient):
    provider_label = "ollama"

    def __init__(self, api_base: str, model: str, timeout: int = 30):
        self.api_base = api_base.rstrip("/")
        self.model = model
        self.timeout = timeout

    @property
    def is_configured(self) -> bool:
        return bool(self.model)

    @property
    def provider_name(self) -> str:
        return f"{self.provider_label}:{self.model}" if self.model else self.provider_label

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str | None:
        if not self.is_configured:
            return None

        payload = {
            "model": self.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "options": {
                "temperature": temperature,
            },
        }
        raw = _post_json(
            url=f"{self.api_base}/api/chat",
            payload=payload,
            timeout=self.timeout,
            headers={"Content-Type": "application/json"},
        )
        if raw is None:
            return None

        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return None
        return _extract_ollama_message(parsed)


class CompositeChatClient(BaseChatClient):
    def __init__(self, clients: list[BaseChatClient]):
        self.clients = clients

    @property
    def is_configured(self) -> bool:
        return any(client.is_configured for client in self.clients)

    @property
    def provider_name(self) -> str:
        for client in self.clients:
            if client.is_configured:
                return client.provider_name
        return "heuristic"

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str | None:
        for client in self.clients:
            if not client.is_configured:
                continue
            answer = client.chat(system_prompt=system_prompt, user_prompt=user_prompt, temperature=temperature)
            if answer:
                return answer
        return None


def build_chat_client(settings: Settings) -> CompositeChatClient:
    openai_client = OpenAICompatibleClient(
        api_base=settings.llm_api_base,
        api_key=settings.llm_api_key,
        model=settings.llm_model,
        timeout=settings.request_timeout,
    )
    ollama_client = OllamaClient(
        api_base=settings.ollama_api_base,
        model=settings.ollama_model,
        timeout=settings.request_timeout,
    )

    provider = settings.llm_provider
    if provider == "ollama":
        return CompositeChatClient([ollama_client, openai_client])
    if provider in {"openai", "openai-compatible"}:
        return CompositeChatClient([openai_client, ollama_client])
    return CompositeChatClient([ollama_client, openai_client])


def _post_json(url: str, payload: dict[str, Any], timeout: int, headers: dict[str, str]) -> str | None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = request.Request(url=url, data=body, headers=headers, method="POST")
    try:
        with request.urlopen(req, timeout=timeout) as response:
            return response.read().decode("utf-8")
    except (error.URLError, error.HTTPError, TimeoutError):
        return None


def _extract_openai_message(payload: dict[str, Any]) -> str | None:
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        return None
    message = choices[0].get("message", {})
    return _extract_message_content(message.get("content"))


def _extract_ollama_message(payload: dict[str, Any]) -> str | None:
    message = payload.get("message")
    if isinstance(message, dict):
        content = _extract_message_content(message.get("content"))
        if content:
            return content

    response_text = payload.get("response")
    if isinstance(response_text, str) and response_text.strip():
        return response_text.strip()
    return None


def _extract_message_content(content: Any) -> str | None:
    if isinstance(content, str):
        return content.strip() or None

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if not isinstance(item, dict):
                continue
            text_value = item.get("text")
            if text_value:
                parts.append(str(text_value))
        merged = "\n".join(parts).strip()
        return merged or None

    return None
