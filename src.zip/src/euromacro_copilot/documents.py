from __future__ import annotations

import csv
import hashlib
import html
import io
import re
from pathlib import Path

from .models import Document
from .text_utils import decode_text_bytes


def load_documents(documents_dir: Path, external_dir: Path) -> list[Document]:
    documents: list[Document] = []
    documents.extend(_load_text_documents(documents_dir, source_type="curated"))
    documents.extend(_load_text_documents(external_dir, source_type="external"))

    speeches_path = external_dir / "all_ECB_speeches.csv"
    if speeches_path.exists():
        documents.extend(_load_ecb_speeches_csv(speeches_path))

    return documents


def _load_text_documents(directory: Path, source_type: str) -> list[Document]:
    documents: list[Document] = []
    if not directory.exists():
        return documents

    for path in sorted(directory.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() not in {".md", ".txt", ".html", ".htm"}:
            continue
        raw_body = _read_text(path)
        front_matter, body = _parse_front_matter(raw_body)
        if not body.strip():
            continue
        title = front_matter.get("title") or _extract_title(path, body)
        url = front_matter.get("url") or None
        metadata = {"path": str(path)}
        for key, value in front_matter.items():
            if key in {"title", "url"}:
                continue
            metadata[key] = value
        documents.append(
            Document(
                doc_id=_stable_id(f"{source_type}:{path.as_posix()}"),
                title=title,
                body=body.strip(),
                source=str(path),
                source_type=source_type,
                url=url,
                metadata=metadata,
            )
        )
    return documents


def _load_ecb_speeches_csv(path: Path, limit: int = 120) -> list[Document]:
    documents: list[Document] = []
    decoded = decode_text_bytes(path.read_bytes())
    with io.StringIO(decoded, newline="") as handle:
        reader = csv.DictReader(handle, delimiter="|")
        rows = list(reader)

    for row in rows[-limit:]:
        content = (row.get("contents") or "").strip()
        if not content:
            continue
        speech_date = (row.get("date") or "").strip()
        title = (row.get("title") or "ECB speech").strip()
        speakers = (row.get("speakers") or "").strip()
        subtitle = (row.get("subtitle") or "").strip()
        header_bits = [bit for bit in [speech_date, speakers, subtitle] if bit]
        header = " | ".join(header_bits)
        body = f"{header}\n\n{content}" if header else content
        documents.append(
            Document(
                doc_id=_stable_id(f"ecb-speech:{speech_date}:{title}"),
                title=title,
                body=body,
                source=str(path),
                source_type="ecb_speech",
                url="https://www.ecb.europa.eu/press/key/html/downloads.en.html",
                metadata={"date": speech_date, "speakers": speakers},
            )
        )
    return documents


def _read_text(path: Path) -> str:
    raw = decode_text_bytes(path.read_bytes())
    if path.suffix.lower() in {".html", ".htm"}:
        return _strip_html(raw)
    return raw


def _strip_html(content: str) -> str:
    without_scripts = re.sub(r"<(script|style)\b.*?</\1>", " ", content, flags=re.IGNORECASE | re.DOTALL)
    without_tags = re.sub(r"<[^>]+>", " ", without_scripts)
    normalized = html.unescape(without_tags)
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized.strip()


def _extract_title(path: Path, body: str) -> str:
    for line in body.splitlines():
        cleaned = line.strip().lstrip("#").strip()
        if cleaned:
            return cleaned
    return path.stem.replace("_", " ").strip()


def _parse_front_matter(body: str) -> tuple[dict[str, str], str]:
    lines = body.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, body

    metadata: dict[str, str] = {}
    closing_index: int | None = None
    for index in range(1, len(lines)):
        line = lines[index].strip()
        if line == "---":
            closing_index = index
            break
        if not line:
            continue
        if ":" not in line:
            return {}, body
        key, value = line.split(":", 1)
        metadata[key.strip().lower()] = value.strip()

    if closing_index is None:
        return {}, body

    content = "\n".join(lines[closing_index + 1 :]).strip()
    return metadata, content


def _stable_id(value: str) -> str:
    return hashlib.md5(value.encode("utf-8")).hexdigest()
