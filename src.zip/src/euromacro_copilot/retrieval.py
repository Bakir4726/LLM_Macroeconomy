from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import replace

from .models import Chunk, Document
from .text_utils import normalize_for_matching

TOKEN_RE = re.compile(r"\b[\w-]{2,}\b", flags=re.UNICODE)


def tokenize(text: str) -> list[str]:
    normalized = normalize_for_matching(text)
    return [token.lower() for token in TOKEN_RE.findall(normalized)]


def chunk_documents(documents: list[Document], chunk_size: int = 900) -> list[Chunk]:
    chunks: list[Chunk] = []
    for document in documents:
        parts = _split_text(document.body, chunk_size=chunk_size)
        for index, part in enumerate(parts):
            chunks.append(
                Chunk(
                    chunk_id=f"{document.doc_id}:{index}",
                    doc_id=document.doc_id,
                    title=document.title,
                    text=part,
                    source=document.source,
                    source_type=document.source_type,
                    url=document.url,
                    metadata=document.metadata,
                )
            )
    return chunks


def _split_text(text: str, chunk_size: int) -> list[str]:
    blocks = [block.strip() for block in re.split(r"\n\s*\n", text) if block.strip()]
    if not blocks:
        return [text.strip()] if text.strip() else []

    chunks: list[str] = []
    current = ""
    for block in blocks:
        if len(block) > chunk_size:
            for sentence_chunk in _split_long_block(block, chunk_size):
                if current:
                    chunks.append(current.strip())
                    current = ""
                chunks.append(sentence_chunk.strip())
            continue

        candidate = f"{current}\n\n{block}".strip() if current else block
        if len(candidate) <= chunk_size:
            current = candidate
        else:
            if current:
                chunks.append(current.strip())
            current = block

    if current:
        chunks.append(current.strip())
    return chunks


def _split_long_block(block: str, chunk_size: int) -> list[str]:
    sentences = re.split(r"(?<=[.!?])\s+", block)
    chunks: list[str] = []
    current = ""
    for sentence in sentences:
        candidate = f"{current} {sentence}".strip() if current else sentence
        if len(candidate) <= chunk_size:
            current = candidate
        else:
            if current:
                chunks.append(current)
            current = sentence[:chunk_size]
    if current:
        chunks.append(current)
    return chunks


class TfidfRetriever:
    def __init__(self, chunks: list[Chunk]):
        self.chunks = chunks
        self._vectors: list[dict[str, float]] = []
        self._norms: list[float] = []
        self._doc_freq: Counter[str] = Counter()
        self._build()

    @classmethod
    def from_documents(cls, documents: list[Document], chunk_size: int = 900) -> "TfidfRetriever":
        return cls(chunk_documents(documents, chunk_size=chunk_size))

    def _build(self) -> None:
        bag_of_words: list[Counter[str]] = []
        for chunk in self.chunks:
            tokens = tokenize(chunk.title) * 3 + tokenize(chunk.text)
            counts = Counter(tokens)
            bag_of_words.append(counts)
            self._doc_freq.update(counts.keys())

        total_docs = max(len(bag_of_words), 1)
        for counts in bag_of_words:
            vector: dict[str, float] = {}
            total_terms = sum(counts.values()) or 1
            for term, count in counts.items():
                tf = count / total_terms
                idf = math.log((total_docs + 1) / (self._doc_freq[term] + 1)) + 1.0
                vector[term] = tf * idf
            norm = math.sqrt(sum(value * value for value in vector.values())) or 1.0
            self._vectors.append(vector)
            self._norms.append(norm)

    def search(self, query: str, top_k: int = 4) -> list[Chunk]:
        if not self.chunks:
            return []

        query_counts = Counter(tokenize(query))
        if not query_counts:
            return [replace(chunk, score=0.0) for chunk in self.chunks[:top_k]]

        total_docs = max(len(self.chunks), 1)
        query_vector: dict[str, float] = {}
        total_terms = sum(query_counts.values()) or 1
        for term, count in query_counts.items():
            tf = count / total_terms
            idf = math.log((total_docs + 1) / (self._doc_freq[term] + 1)) + 1.0
            query_vector[term] = tf * idf
        query_norm = math.sqrt(sum(value * value for value in query_vector.values())) or 1.0

        scored: list[Chunk] = []
        for chunk, vector, norm in zip(self.chunks, self._vectors, self._norms):
            dot_product = 0.0
            for term, weight in query_vector.items():
                dot_product += weight * vector.get(term, 0.0)
            score = dot_product / (query_norm * norm)
            if score > 0:
                scored.append(replace(chunk, score=round(score, 4)))

        if not scored:
            return [replace(chunk, score=0.0) for chunk in self.chunks[:top_k]]

        scored.sort(key=lambda item: item.score, reverse=True)
        return scored[:top_k]

    def full_corpus_text(self) -> str:
        return "\n\n".join(chunk.text for chunk in self.chunks)
