from __future__ import annotations

import shutil
import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from euromacro_copilot.documents import load_documents


class DocumentsTests(unittest.TestCase):
    def test_load_documents_supports_cp1252_files(self) -> None:
        root = PROJECT_ROOT / "data" / "cache" / "test_documents_cp1252"
        try:
            shutil.rmtree(root, ignore_errors=True)
            documents_dir = root / "documents"
            external_dir = root / "external"
            documents_dir.mkdir(parents=True)
            external_dir.mkdir(parents=True)

            sample = "# Economie francaise\nLes couts d'energie pesent sur l'activite."
            (documents_dir / "note.md").write_bytes(sample.encode("cp1252"))

            documents = load_documents(documents_dir, external_dir)

            self.assertEqual(len(documents), 1)
            self.assertEqual(documents[0].title, "Economie francaise")
            self.assertIn("Les couts d'energie", documents[0].body)
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_load_documents_parses_front_matter_url(self) -> None:
        root = PROJECT_ROOT / "data" / "cache" / "test_documents_front_matter"
        try:
            shutil.rmtree(root, ignore_errors=True)
            documents_dir = root / "documents"
            external_dir = root / "external"
            documents_dir.mkdir(parents=True)
            external_dir.mkdir(parents=True)

            sample = (
                "---\n"
                "title: Conditions de credit\n"
                "url: https://example.com/source\n"
                "theme: financement\n"
                "---\n"
                "\n"
                "Le resserrement du credit pese sur l'investissement."
            )
            (documents_dir / "note.md").write_text(sample, encoding="utf-8")

            documents = load_documents(documents_dir, external_dir)

            self.assertEqual(len(documents), 1)
            self.assertEqual(documents[0].title, "Conditions de credit")
            self.assertEqual(documents[0].url, "https://example.com/source")
            self.assertEqual(documents[0].metadata["theme"], "financement")
            self.assertIn("resserrement du credit", documents[0].body)
        finally:
            shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
