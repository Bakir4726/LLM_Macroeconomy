from __future__ import annotations

import sys
import unittest
from datetime import date
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from euromacro_copilot.analytics import build_business_scenario, compute_uncertainty_score, detect_narratives
from euromacro_copilot.models import MacroSnapshot


class AnalyticsTests(unittest.TestCase):
    def test_detect_narratives_and_uncertainty(self) -> None:
        text = (
            "Les prix de l'énergie restent volatils et l'incertitude est élevée. "
            "Les conditions de crédit se resserrent et les entreprises signalent une demande plus faible."
        )
        narratives = detect_narratives(text, limit=5)
        names = {item.name for item in narratives}
        self.assertIn("choc énergie", names)
        self.assertIn("resserrement financier", names)
        self.assertGreater(compute_uncertainty_score(text), 0)

    def test_build_scenario_flags_financing_risk(self) -> None:
        snapshot = {
            "hicp": MacroSnapshot(
                indicator="hicp",
                label="Headline inflation",
                latest_date=date(2026, 2, 28),
                latest_value=2.2,
                previous_value=2.3,
                delta=-0.1,
                unit="percent",
                source="demo",
                trend="down",
            ),
            "core_inflation": MacroSnapshot(
                indicator="core_inflation",
                label="Core inflation",
                latest_date=date(2026, 2, 28),
                latest_value=2.6,
                previous_value=2.7,
                delta=-0.1,
                unit="percent",
                source="demo",
                trend="down",
            ),
            "gdp_growth": MacroSnapshot(
                indicator="gdp_growth",
                label="GDP growth qoq",
                latest_date=date(2026, 2, 28),
                latest_value=0.1,
                previous_value=0.2,
                delta=-0.1,
                unit="percent",
                source="demo",
                trend="down",
            ),
            "unemployment_rate": MacroSnapshot(
                indicator="unemployment_rate",
                label="Unemployment rate",
                latest_date=date(2026, 2, 28),
                latest_value=6.2,
                previous_value=6.3,
                delta=-0.1,
                unit="percent",
                source="demo",
                trend="down",
            ),
            "borrowing_cost": MacroSnapshot(
                indicator="borrowing_cost",
                label="Corporate borrowing cost",
                latest_date=date(2026, 2, 28),
                latest_value=4.2,
                previous_value=4.3,
                delta=-0.1,
                unit="percent",
                source="demo",
                trend="down",
            ),
        }
        narratives = detect_narratives("Credit conditions are tighter and uncertainty is elevated.", limit=3)
        scenario = build_business_scenario(snapshot, narratives, uncertainty_score=24.0)
        self.assertIn("financement", scenario.financing.lower())
        self.assertTrue(scenario.watchlist)


if __name__ == "__main__":
    unittest.main()
