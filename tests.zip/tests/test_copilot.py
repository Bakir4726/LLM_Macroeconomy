from __future__ import annotations

import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from euromacro_copilot.config import Settings
from euromacro_copilot.copilot import EuroMacroCopilot
from euromacro_copilot.llm import BaseChatClient
from euromacro_copilot.macro_data import MacroStore
from euromacro_copilot.models import Document
from euromacro_copilot.retrieval import TfidfRetriever


class FakeChatClient(BaseChatClient):
    provider_label = "fake"

    @property
    def is_configured(self) -> bool:
        return True

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str | None:
        return (
            "### Diagnostic\n"
            "Les conditions de financement restent tendues [S1].\n\n"
            "### Implications PME\n"
            "Prioriser la tresorerie et le pricing.\n\n"
            "### Variables a surveiller\n"
            "Credit bancaire, inflation sous-jacente, demande."
        )


class CopilotAnswerTests(unittest.TestCase):
    def test_answer_appends_sources_and_documents(self) -> None:
        settings = Settings.from_project_root(PROJECT_ROOT)
        retriever = TfidfRetriever.from_documents(
            [
                Document(
                    doc_id="doc-a",
                    title="Conditions de credit",
                    body="Le credit bancaire se durcit et le cout du financement reste eleve pour les entreprises.",
                    source="memory",
                    source_type="test",
                    url="https://example.com/credit",
                ),
                Document(
                    doc_id="doc-b",
                    title="Marche du travail",
                    body="Le marche du travail reste solide mais les hausses salariales entretiennent les couts.",
                    source="memory",
                    source_type="test",
                    url="https://example.com/labour",
                ),
            ],
            chunk_size=160,
        )
        macro_store = MacroStore.from_csv(PROJECT_ROOT / "data" / "series" / "euro_macro_demo.csv")
        copilot = EuroMacroCopilot(
            settings=settings,
            retriever=retriever,
            macro_store=macro_store,
            llm_client=FakeChatClient(),
        )

        response = copilot.answer("Que signifie le durcissement du credit pour une PME ?", top_k=1)

        self.assertIn("### Sources", response.answer)
        self.assertIn("### Documents complémentaires", response.answer)
        self.assertTrue(response.documents)
        self.assertEqual(response.documents[0].title, "Marche du travail")


if __name__ == "__main__":
    unittest.main()
