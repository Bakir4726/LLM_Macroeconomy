from __future__ import annotations

import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from euromacro_copilot.models import Document
from euromacro_copilot.retrieval import TfidfRetriever


class RetrievalTests(unittest.TestCase):
    def test_query_prefers_financing_document(self) -> None:
        documents = [
            Document(
                doc_id="doc-a",
                title="Financement et crédit",
                body="Les coûts de financement augmentent et les conditions de crédit se durcissent.",
                source="memory",
                source_type="test",
            ),
            Document(
                doc_id="doc-b",
                title="Marché du travail",
                body="Le marché du travail reste solide avec un taux de chômage faible.",
                source="memory",
                source_type="test",
            ),
        ]
        retriever = TfidfRetriever.from_documents(documents, chunk_size=160)
        results = retriever.search("crédit coût du financement", top_k=1)
        self.assertEqual(results[0].title, "Financement et crédit")


if __name__ == "__main__":
    unittest.main()
